/**
 */
package edu.ustb.sei.mde.smartContractSpecification;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Slot</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.ustb.sei.mde.smartContractSpecification.SmartContractSpecificationPackage#getDataSlot()
 * @model abstract="true"
 * @generated
 */
public interface DataSlot extends NamedElement {
} // DataSlot
