/**
 */
package edu.ustb.sei.mde.smartContractSpecification;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Internal Party</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.ustb.sei.mde.smartContractSpecification.SmartContractSpecificationPackage#getInternalParty()
 * @model abstract="true"
 * @generated
 */
public interface InternalParty extends Party, DataSlot, FieldContainer {
} // InternalParty
